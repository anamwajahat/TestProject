﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.ComponentHelper;
using TestFramework.Configuration;
using TestFramework.Settings;

namespace TestFramework.TestScripts.PageObject
{
    [Binding]
    public class Blog
    {
        private readonly IWebDriver _driver;
        private readonly GenericHelper _genericHelper;
        public Blog(IWebDriver driver, GenericHelper genericHelper)
        {
            _driver = driver;
            _genericHelper = genericHelper;
        }
        #region WebElement
        private IWebElement Title => _driver.FindElement(By.ClassName("page-title"));
        #endregion

        #region method
        public bool TitleDisplayed() => Title.Displayed;
        public void WaitForTitleToBeDisplayed() => _genericHelper.WaitForElementInPage(Title, 1000);
        #endregion
    }
}
