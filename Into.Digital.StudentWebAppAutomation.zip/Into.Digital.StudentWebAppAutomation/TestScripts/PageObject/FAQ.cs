﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;
using TestFramework.Configuration;
using TestFramework.Settings;

namespace TestFramework.TestScripts.PageObject
{
    public class FAQ
    {
        private readonly IWebDriver _driver;

        public FAQ(IWebDriver driver)
        {
            _driver = driver;
        }
        #region IWebElements
        private IWebElement NavItemLevel2 => _driver.FindElement(By.CssSelector("#header-breadcrumb>div>.desktop-only>span>a:nth-of-type(3)"));
        #endregion

        #region method
        public bool NavItemLevel2Displayed() => NavItemLevel2.Displayed;
        public bool NavItemLevel2TextIsCorrect(String text) => NavItemLevel2.Text.Contains(text);

        #endregion
    }
}
