﻿using TechTalk.SpecFlow;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TestFramework.ComponentHelper;
using TestFramework.Settings;
using SeleniumExtras.PageObjects;
using TestFramework.Configuration;

namespace TestFramework.TestScripts.PageObject
{
    [Binding]
    public class NavigationBar 
    {
        private readonly IWebDriver _driver;
        private readonly JSHelper _jSHelper;
        private readonly ActionsHelper _actionsHelper;
        private readonly GenericHelper _genericHelper;
        public NavigationBar(IWebDriver driver, JSHelper jSHelper, ActionsHelper actionsHelper, GenericHelper genericHelper)
        {
            _driver = driver;
            _jSHelper = jSHelper;
            _actionsHelper = actionsHelper;
            _genericHelper = genericHelper;
        }

        #region WebElement
        private IWebElement AboutINTOLink => _driver.FindElement(By.LinkText("About INTO"));
        private string AboutINTOAtribute => AboutINTOLink.GetAttribute("href");
        private IWebElement SuccessWithINTOLink => _driver.FindElement(By.CssSelector(".into-desktop-menu>.cantarus-megamenu>.has-submenu:nth-of-type(1)>.submenu>.submenu-container>.menu-wrap-inner>.sub-menu-nav>li:nth-of-type(1)>a"));
        private string SuccessWithINTOAtribute => SuccessWithINTOLink.GetAttribute("href");
        private IWebElement Blog => _driver.FindElement(By.CssSelector(".into-desktop-menu>.cantarus-megamenu>.has-submenu:nth-of-type(1)>.submenu>.submenu-container>.menu-wrap-inner>.sub-menu-nav>li:nth-of-type(2)>a"));
        private string BlogAtribute => Blog.GetAttribute("href");
        private IWebElement FAQ => _driver.FindElement(By.CssSelector(".into-desktop-menu>.cantarus-megamenu>.has-submenu:nth-of-type(1)>.submenu>.submenu-container>.menu-wrap-inner>.sub-menu-nav>li:nth-of-type(3)>a"));
        private string FAQAtribute => FAQ.GetAttribute("href");
        private IWebElement RecommendAFriend => _driver.FindElement(By.CssSelector(".into-desktop-menu>.cantarus-megamenu>.has-submenu:nth-of-type(1)>.submenu>.submenu-container>.menu-wrap-inner>.sub-menu-nav>li:nth-of-type(4)>a"));
        private string RecommendAFriendAtribute => RecommendAFriend.GetAttribute("href");
        private string AboutINTOURL => "en/about-into";
        private string SuccessWithINTOURL => "en/success-with-into";
        private string BlogURL => "https://blog.intostudy.com/";
        private string FAQURL => "en/help/faq";
        private string RecommendAFriendURL => "https://go.intostudy.com/friend";

        #endregion

        #region Methods
        public bool AboutINTOLinkIsDisplayed() => AboutINTOLink.Displayed; 
        public bool SuccessWithINTOLinkIsDisplayed() => SuccessWithINTOLink.Displayed; 
        public void WaitForSuccessWithINTOLink() => _genericHelper.WaitForElementInPage(SuccessWithINTOLink, 1000); 
        public bool BlogIsDisplayed() => Blog.Displayed; 
        public bool FAQIsDisplayed() => FAQ.Displayed; 
        public bool RecommendAFriendIsDisplayed() => RecommendAFriend.Displayed; 
        public void OpenAboutINTOInANewTab() => _jSHelper.OpenInNewTab(AboutINTOAtribute);
        public void OpenSuccessWithINTOAttInANewTab() => _jSHelper.OpenInNewTab(SuccessWithINTOAtribute);
        public void OpenBlogAttInANewTab() => _jSHelper.OpenInNewTab(BlogAtribute);
        public void OpenFAQAttInANewTab() => _jSHelper.OpenInNewTab(FAQAtribute);
        public void OpenRecommendAFriendAttInANewTab() => _jSHelper.OpenInNewTab(RecommendAFriendAtribute);
        public void MoveToAboutINTOLink() => _actionsHelper.MoveToElement(AboutINTOLink);
        public bool AboutINTOURLIsCorrect() => _driver.Url.Contains(AboutINTOURL);
        public bool SuccessWithINTOURLIsCorrect() => _driver.Url.Contains(SuccessWithINTOURL);
        public bool BlogURLIsCorrect() => _driver.Url.Contains(BlogURL);
        public bool FAQURLIsCorrect() => _driver.Url.Contains(FAQURL);
        public bool RecommendAFriendURLIsCorrect() => _driver.Url.Contains(RecommendAFriendURL);

        #endregion
    }
}
