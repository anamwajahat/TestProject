﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.ComponentHelper;
using TestFramework.Configuration;
using TestFramework.Settings;

namespace TestFramework.TestScripts.PageObject
{
    [Binding]
    public class AboutINTO
    {
        private readonly IWebDriver _driver;
        private readonly GenericHelper _genericHelper;

        public AboutINTO(IWebDriver driver, GenericHelper genericHelper)
        {
            _driver = driver;
            _genericHelper = genericHelper;
        }

        #region IWebElements
        private IWebElement NavItem => _driver.FindElement(By.CssSelector("#header-breadcrumb>div>.desktop-only>span>a:nth-of-type(2)"));
        #endregion

        #region method
        public bool NavItemDisplayed() => NavItem.Displayed;
        public void WaitForNavItemToBeDisplayed() => _genericHelper.WaitForElementInPage(NavItem, 1000);
        public void WaitForNavItemToContainText(String text) => _genericHelper.WaitForElementToContainText(NavItem, 1000, text);
        public bool NavItemTextIsCorrect(String text) => NavItem.Text.Contains(text);
        #endregion

    }
}
