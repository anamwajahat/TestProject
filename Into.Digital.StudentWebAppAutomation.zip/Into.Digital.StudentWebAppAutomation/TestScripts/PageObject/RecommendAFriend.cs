﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.ComponentHelper;
using TestFramework.Configuration;
using TestFramework.Settings;

namespace TestFramework.TestScripts.PageObject
{
    [Binding]
    public class RecommendAFriend
    {
        private readonly IWebDriver _driver;
        private readonly GenericHelper _genericHelper ;
        public RecommendAFriend(IWebDriver driver, GenericHelper genericHelper) 
        {
            _driver = driver;
            _genericHelper = genericHelper;
        }
        #region WebElement
        private IWebElement TitleImage => _driver.FindElement(By.ClassName("page-element"));
        #endregion

        #region method
        public bool TitleImageIsDisplayed() => TitleImage.Displayed;
        public void WaitForTitleImageToBeDisplayed() => _genericHelper.WaitForElementInPage(TitleImage, 1000);

        #endregion
    }
}
