﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.Settings;

namespace TestFramework.TestScripts.PageObject
{
    [Binding]
    public class SuccessWithINTO
    {
        //private static IWebDriver Driver;

        //public SuccessWithINTO(IWebDriver driver)
        //{
        //    Driver = driver;
        //}

        #region Method

        #endregion
    }
}
