﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.ComponentHelper;

namespace TestFramework.TestScripts.PageObject
{
    [Binding]
    public class Cloudinary
    {
        private readonly IWebDriver _driver;
        private readonly GenericHelper _genericHelper;

        public Cloudinary(IWebDriver driver, GenericHelper genericHelper)
        {
            _driver = driver;
            _genericHelper = genericHelper;
        }

        private IWebElement CenterDropdown => _driver.FindElement(By.TagName("select"));
        private IWebElement DropZone => _driver.FindElement(By.TagName("dropzone"));
        private IWebElement Username => _driver.FindElement(By.Id("i0116"));
        private IWebElement Password => _driver.FindElement(By.Name("passwd"));
        private IWebElement NextButton => _driver.FindElement(By.Id("idSIButton9"));
        private IWebElement Filename => _driver.FindElement(By.ClassName("dz-filename"));

        public void NavigateToURL() => _driver.Navigate().GoToUrl("https://login.microsoftonline.com/335d0576-4b23-4316-9e3a-aef25ac54543/oauth2/v2.0/authorize?response_type=id_token&scope=user.read%20email%20openid%20profile&client_id=c21ef1a1-9df2-4141-bf2e-f2a99600c16d&redirect_uri=https%3A%2F%2Fwebneutstedxx01.azurewebsites.net%2Fcallback&state=eyJpZCI6IjhkYWFjYjRmLWI3YzgtNDEyNS1iZWYyLTk1ZTdhM2FlNTJkZCIsInRzIjoxNjA5Nzc4NTY0LCJtZXRob2QiOiJyZWRpcmVjdEludGVyYWN0aW9uIn0%3D&nonce=16fbbe29-74f1-4918-9505-b8c0b85b26a3&client_info=1&x-client-SKU=MSAL.JS&x-client-Ver=1.3.2&client-request-id=15b4679b-c03c-4a30-b697-f93884999e04&response_mode=fragment&sso_reload=true");
        public void ClickNextbutton() => NextButton.Click();
        public void WaitForCenterDropdown() => _genericHelper.WaitForElementInPage(CenterDropdown, 1000);
        public void WaitForUsernameField() => _genericHelper.WaitForElementInPage(Username, 1000);
        public void WaitForPasswordField() => _genericHelper.WaitForElementInPage(Password, 1000);
        public void TypeUsername() => Username.SendKeys("anam.wajahat@intoglobal.com");
        public void TypePassword() => Password.SendKeys("Manager@28893");
        public bool FileNameDisplayed() => Filename.Displayed;
        public void SelectCenter(string center)
        {
            SelectElement oSelect = new SelectElement(CenterDropdown);

            oSelect.SelectByText(center);
        }
        public void UploadDoc() => _genericHelper.UploadDocument(DropZone);
        public bool DropZoneVisible() => DropZone.Displayed;
    }
        
}
