﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.ComponentHelper;
using TestFramework.Configuration;
using TestFramework.Settings;

namespace TestFramework.TestScripts.PageObject
{
    [Binding]
    public class Homepage 
    {
        private readonly IWebDriver _driver;
        private readonly GenericHelper _genericHelper;
        public Homepage(IWebDriver driver, GenericHelper genericHelper)
        {
            _driver = driver;
            _genericHelper = genericHelper;
        }
        #region WebElement
        private IWebElement Logo => _driver.FindElement(By.Id("main-logo"));
        private IWebElement HomepageTitle => _driver.FindElement(By.ClassName("title"));
        #endregion

        #region Method
        public bool LogoIsDisplayed() => Logo.Displayed;
        public bool HomepageTitleIsDisplayed() => HomepageTitle.Displayed;
        public void WaitforLogo() => _genericHelper.WaitForElementInPage(Logo, 1000);
        #endregion
    }
}
