﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using TestFramework.TestScripts.PageObject;

namespace TestFramework.TestScripts.StepDefinition
{
    [Binding]
    public class UploadFunctionalitySD
    {
        private readonly Cloudinary _cloudinary;

        public UploadFunctionalitySD(Cloudinary cloudinary)
        {
            _cloudinary = cloudinary;
        }

        [Given(@"user enters username")]
        public void GivenUserEntersUsername()
        {
            _cloudinary.TypeUsername();
            _cloudinary.ClickNextbutton();
            Thread.Sleep(5000);
            _cloudinary.WaitForPasswordField();
        }

        [Given(@"user enter password")]
        public void GivenUserEnterPassword()
        {
            _cloudinary.TypePassword();
            _cloudinary.ClickNextbutton();
            Thread.Sleep(5000);
            _cloudinary.WaitForCenterDropdown();
        }

        [Given(@"User is on Cloudinary")]
        public void GivenUserIsOnCloudinary()
        {
            try
            {
                _cloudinary.NavigateToURL();
                Thread.Sleep(5000);
                _cloudinary.WaitForUsernameField();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [When(@"User selects a center")]
        public void WhenUserSelectsACenter()
        {
            try
            {
                _cloudinary.SelectCenter("City, University of London");
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [When(@"User tries to upload a file")]
        public void WhenUserTriesToUploadAFile()
        {
            try
            {
                Assert.IsTrue(_cloudinary.DropZoneVisible());
                _cloudinary.UploadDoc();
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        [Then(@"It gets successfully uploaded")]
        public void ThenItGetsSuccessfullyUploaded()
        {
            try
            {
                Assert.IsTrue(_cloudinary.FileNameDisplayed());
            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }
}
