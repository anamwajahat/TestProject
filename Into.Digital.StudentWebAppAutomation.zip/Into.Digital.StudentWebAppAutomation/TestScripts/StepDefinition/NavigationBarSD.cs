﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.ComponentHelper;
using TestFramework.Configuration;
using TestFramework.Hooks;
using TestFramework.Settings;
using TestFramework.TestScripts.PageObject;

namespace TestFramework.TestScripts.StepDefinition
{
    [Binding]
    public class NavigationBarSD 
    {
        private readonly Homepage _homepage;
        private readonly RecommendAFriend _recommendAFriend;
        private readonly AboutINTO _aboutINTO;
        private readonly Blog _blog;
        private readonly FAQ _faq;
        private readonly NavigationBar _navigationBar;
        private readonly GenericHelper _genericHelper;
        public NavigationBarSD(Homepage homepage, RecommendAFriend recommendAFriend, AboutINTO aboutINTO, Blog blog, FAQ faq, NavigationBar navigationBar, GenericHelper genericHelper)
        {
            
            _homepage = homepage;
            _recommendAFriend = recommendAFriend;
            _aboutINTO = aboutINTO;
            _blog = blog;
            _faq = faq;
            _navigationBar = navigationBar;
            _genericHelper = genericHelper;
        }

        #region Given
        [Given(@"User is on IS homepage")]
        public void GivenUserIsOnISHomepage()
        {
            try
            {
                _genericHelper.NavigateToIS();
                _homepage.WaitforLogo();
                Assert.IsTrue(_homepage.LogoIsDisplayed(), "Logo not displayed on homepage");
                Assert.IsTrue(_homepage.HomepageTitleIsDisplayed(), "Homepage title not displayed");
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region When
        [When(@"I look at About INTO")]
        public void WhenILookAtAboutINTO()
        {
            try
            {
                Assert.IsTrue(_navigationBar.AboutINTOLinkIsDisplayed(), "About INTO link not displayed");
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [When(@"I click About INTO")]
        public void WhenIClickAboutINTO()
        {
            try
            {
                _navigationBar.OpenAboutINTOInANewTab();
                _aboutINTO.WaitForNavItemToBeDisplayed();
                _aboutINTO.WaitForNavItemToContainText("About INTO");
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [When(@"I click '(.*)' from about INTO submenu")]
        public void WhenIClickFromAboutINTOSubmenu(string _SubMenu)
        {
            try
            {
                _navigationBar.MoveToAboutINTOLink();
                _navigationBar.WaitForSuccessWithINTOLink();
                if (_SubMenu.Contains("Success with INTO"))
                {
                    _navigationBar.OpenSuccessWithINTOAttInANewTab();
                    _genericHelper.SwitchWindow(1);
                    _aboutINTO.WaitForNavItemToContainText("Success with INTO"); ;
                }
                else if (_SubMenu.Contains("Blog"))
                {
                    _navigationBar.OpenBlogAttInANewTab();
                    _genericHelper.SwitchWindow(1);
                    _blog.WaitForTitleToBeDisplayed();
                }
                else if (_SubMenu.Contains("FAQ"))
                {
                    _navigationBar.OpenFAQAttInANewTab();
                    _genericHelper.SwitchWindow(1);
                    _aboutINTO.WaitForNavItemToBeDisplayed();
                    _aboutINTO.WaitForNavItemToContainText("Help"); 
                }
                else if (_SubMenu.Contains("Recommend a friend"))
                {
                    _navigationBar.OpenRecommendAFriendAttInANewTab(); ;
                    _genericHelper.SwitchWindow(1);
                    _recommendAFriend.WaitForTitleImageToBeDisplayed();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion

        #region Then
        [Then(@"I should be displayed correct submenues")]
        public void ThenIShouldBeDisplayedCorrectSubmenues()
        {
            try
            {
                _navigationBar.MoveToAboutINTOLink();
                _navigationBar.WaitForSuccessWithINTOLink();
                Assert.IsTrue(_navigationBar.SuccessWithINTOLinkIsDisplayed(), "Success with INTO link not displayed");
                Assert.IsTrue(_navigationBar.BlogIsDisplayed(), "Blog link not displayed");
                Assert.IsTrue(_navigationBar.FAQIsDisplayed(), "FAQ link not displayed");
                Assert.IsTrue(_navigationBar.RecommendAFriendIsDisplayed(), "Recommend a friend link not displayed");
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [Then(@"I am redirected to About INTO page")]
        public void ThenIAmRedirectedToAboutINTOPage()
        {
            try
            {
                Assert.IsTrue(_navigationBar.AboutINTOURLIsCorrect(), "About INTO URL is incorrect");
                Assert.IsTrue(_aboutINTO.NavItemTextIsCorrect("About INTO"), "The header text on About INTO page is incorrect");
                _genericHelper.CloseWindow();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [Then(@"I am redirected to '(.*)' page from about INTO submenu")]
        public void ThenIAmRedirectedToPageFromAboutINTOSubmenu(string _SubMenu)
        {
            try
            {
                if (_SubMenu.Contains("Success with INTO"))
                {
                    Assert.IsTrue(_navigationBar.SuccessWithINTOURLIsCorrect(), "Success with INTO url is incorrect");
                    Assert.IsTrue(_aboutINTO.NavItemTextIsCorrect("Success with INTO"), "The header text on success with INTO page is incorrect");
                }
                else if (_SubMenu.Contains("Blog"))
                {
                    Assert.IsTrue(_navigationBar.BlogURLIsCorrect(), "Blog url is incorrect");
                }
                else if (_SubMenu.Contains("FAQ"))
                {
                    Assert.IsTrue(_navigationBar.FAQURLIsCorrect(),"FAQ url is incorrect");
                    Assert.IsTrue(_aboutINTO.NavItemTextIsCorrect("Help"), "The header text on FAQ page is incorrect");
                    Assert.IsTrue(_faq.NavItemLevel2TextIsCorrect("FAQ"),  "The second level header text on FAQ page is incorrect");
                }
                else if (_SubMenu.Contains("Recommend a friend"))
                {
                    Assert.IsTrue(_navigationBar.RecommendAFriendURLIsCorrect(), "Recomend a friend url is incorrect");
                    Assert.IsTrue(_recommendAFriend.TitleImageIsDisplayed());
                }

                _genericHelper.CloseWindow();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        #endregion
    }
}
