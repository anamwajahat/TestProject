﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using TestFramework.Interface;
using TestFramework.Settings;

namespace TestFramework.Configuration
{
    public class AppSettingReader : IConfig
    {
        //Gets Browser value from appsettings.json file
        public BrowserType GetBrowser()
        {
            String reqDir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\appsettings.json"));

            string browser = new ConfigurationBuilder()
                .AddJsonFile(reqDir, true)
                .AddEnvironmentVariables()
                .Build().Get<MyConfiguration>().Browser;
            
            return (BrowserType)Enum.Parse(typeof(BrowserType), browser);
        }

        //Gets Environment value from appsettings.json file
        public string GetEnvironment()
        {
            String reqDir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\appsettings.json"));

            var mySettingsConfig = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(reqDir, true)
                .AddEnvironmentVariables()
                .Build().Get<MyConfiguration>().Environment;

            return mySettingsConfig;
        }

        //Gets Page load timeout value from appsettings.json file
        public int GetPageLoadTimeout()
        {
            String reqDir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\appsettings.json"));

            String timeout = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(reqDir, true)
                .AddEnvironmentVariables()
                .Build().Get<MyConfiguration>().PageLoadTimeout;

            if (timeout == null)
                return 30;
            return Convert.ToInt32(timeout);
        }

        //Gets Implicit Wait timeout value from appsettings.json file
        public int GetImplicitWaitTimeout()
        {
            String reqDir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\appsettings.json"));

            String timeout = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
             .AddJsonFile(reqDir, true)
             .AddEnvironmentVariables()
             .Build().Get<MyConfiguration>().ImplicitWaitTimeout;

            if (timeout == null)
                return 30;
            return Convert.ToInt32(timeout);
        }
        
    }
}
