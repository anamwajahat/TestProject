﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestFramework.Settings
{
    public class MyConfiguration
    {
       
        public string Browser { get; set; }
        public string Environment { get; set; }
        public string PageLoadTimeout { get; set; }
        public string ImplicitWaitTimeout { get; set; }
    }
}
