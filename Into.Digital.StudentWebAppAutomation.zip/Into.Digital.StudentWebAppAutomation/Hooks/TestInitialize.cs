﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Model;
using AventStack.ExtentReports.Reporter;
using BoDi;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using TestFramework.ComponentHelper;
using TestFramework.Configuration;
using TestFramework.CustomException;
using TestFramework.Interface;
using TestFramework.Settings;

namespace TestFramework.Hooks
{

    [Binding]
    public class TestInitialize
    {
        private static ExtentReports _extentReports;
        private static ExtentHtmlReporter _extentHTMLreporter;
        private static ThreadLocal<ExtentTest> _extentFeature;
        private static ExtentTest _feature;
        private readonly ScenarioContext _scenarioContext;
        private ExtentTest _scenario;
        private readonly IObjectContainer _container;
        private readonly AppSettingReader _iconfig;
        private IWebDriver _driver;
        private GenericHelper _genericHelper;
        private readonly URLs _urls;

        public TestInitialize(IObjectContainer container, AppSettingReader iconfig, ScenarioContext scenarioContext, URLs urls)
        {
            _container = container;
            _iconfig = iconfig;
            _scenarioContext = scenarioContext;
            _urls = urls;
           // _genericHelper = genericHelper;
        }

        [BeforeTestRun]
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void BeforeTestRun()
        {
            
            String reqDir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\Result\Data\Log\"));
            if(_extentHTMLreporter == null)
            {
                _extentHTMLreporter = new ExtentHtmlReporter(reqDir);
                _extentHTMLreporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
                _extentHTMLreporter.Config.CSS = "img.r-img { width: 750px; padding-left: 40px;padding-top: 10px;}";
                _extentHTMLreporter.Config.ReportName = "Web Automation Results";
                _extentHTMLreporter.Config.DocumentTitle = "Test Result";
            }
            if(_extentReports == null)
            {
                _extentReports = new ExtentReports();
                _extentReports.AttachReporter(_extentHTMLreporter);
            }

        }

        [BeforeFeature]
        public static void BeforeFeatureStart(FeatureContext featureContext)
        {
            _extentFeature = new ThreadLocal<ExtentTest>();
            if(null != featureContext)
            {
                if(_feature == null)
                {
                    _feature = _extentReports.CreateTest<Feature>(featureContext.FeatureInfo.Title,
                    featureContext.FeatureInfo.Description);
                    _extentFeature.Value = _feature;
                }
            }
        }


        [BeforeScenario]
        public void Initialize()
        {
            
            if (null != _scenarioContext)
            {
                _scenario = _extentFeature.Value.CreateNode<Scenario>(_scenarioContext.ScenarioInfo.Title,
                    _scenarioContext.ScenarioInfo.Description);
            }
            LoadBrowser();
            ConfigureURL();
            _genericHelper = new GenericHelper(_driver, _iconfig, _scenarioContext, _urls);
            //_genericHelper.URLConfig();
            //_genericHelper.PageLoadWait();
        }

        [AfterStep]
        public void AfterEachStep()
        {
            ScenarioBlock scenarioBlock = _scenarioContext.CurrentScenarioBlock;
            String reqDir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\Result\ScreenShots\"));

            switch (scenarioBlock)
            {
                case ScenarioBlock.Given:
                    if (_scenarioContext.TestError != null)
                    {
                        _scenario.CreateNode<Given>(_scenarioContext.StepContext.StepInfo.Text).Fail
                            (_scenarioContext.TestError.Message + "\n" + "\n" + _scenarioContext.TestError.StackTrace + "\n")
                            .AddScreenCaptureFromPath(reqDir + _genericHelper.TakeScreenShot() + ".jpg");
                    }
                    else
                    {
                        _scenario.CreateNode<Given>(_scenarioContext.StepContext.StepInfo.Text).Pass("");
                        
                    }
                    break;
                case ScenarioBlock.When:
                    if (_scenarioContext.TestError != null)
                    {
                        _scenario.CreateNode<When>(_scenarioContext.StepContext.StepInfo.Text).Fail
                            (_scenarioContext.TestError.Message + "\n" +"\n"+ _scenarioContext.TestError.StackTrace)
                            .AddScreenCaptureFromPath(reqDir + _genericHelper.TakeScreenShot() + ".jpg");
                    }
                    else
                    {
                        _scenario.CreateNode<When>(_scenarioContext.StepContext.StepInfo.Text).Pass("");
                        
                    }
                    break;
                case ScenarioBlock.Then:
                    if (_scenarioContext.TestError != null)
                    {
                        _scenario.CreateNode<Then>(_scenarioContext.StepContext.StepInfo.Text).Fail
                            (_scenarioContext.TestError.Message + "\n" + "\n" + _scenarioContext.TestError.StackTrace)
                            .AddScreenCaptureFromPath(reqDir + _genericHelper.TakeScreenShot() + ".jpg");
                    }
                    else
                    {
                        _scenario.CreateNode<Then>(_scenarioContext.StepContext.StepInfo.Text).Pass("");
                       
                    }
                    break;
                default:
                    if (_scenarioContext.TestError != null)
                    {
                        _scenario.CreateNode<And>(_scenarioContext.StepContext.StepInfo.Text).Fail
                            (_scenarioContext.TestError.Message +"\n" + "\n" + _scenarioContext.TestError.StackTrace)
                            .AddScreenCaptureFromPath(reqDir + _genericHelper.TakeScreenShot() + ".jpg");
                    }
                    else
                    {
                        _scenario.CreateNode<And>(_scenarioContext.StepContext.StepInfo.Text).Pass("");
                        
                    }
                    break;
                    
            }
        }

        [AfterTestRun]
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void AfterTestRun()
        {
            _extentReports.Flush();
        }

        [AfterScenario]
        public void Cleanup()
        {
            if (_scenarioContext.TestError != null)
            {
                Console.WriteLine(_scenarioContext.TestError.Message);
                Console.WriteLine(_scenarioContext.TestError.StackTrace);
            }
            if (_driver != null)
            {
                _driver.Close();
                _driver.Quit();
                _driver.Dispose();
            }
        }

        //Loads a browser depending on what has been entered in appsettings.json file
        private void LoadBrowser()
        {
            _driver = (_iconfig.GetBrowser()) switch
            {
                BrowserType.Chrome => GetChromeDriver(),
                BrowserType.Firefox => GetFirefoxDriver(),
                _ => throw new NoSuitableDriverFound("Driver not found : " + _iconfig.GetBrowser().ToString()),
            };
        }
        //Navigates to a URL depending on what has been entered in appsettings.json file
        private void ConfigureURL()
        {
            if (_iconfig.GetEnvironment().Equals("Live"))
            {
                _urls.ISURL = "https://www.intostudy.com/en";
                _urls.MyAccountURL = "https://login-myaccount.intostudy.com/login?state=g6Fo2SB1RUxGMWE1ODhqWmJNbnd4WDFxMER4Ql9SZ2VFelREeaN0aWTZIG9Vam5MWExxa1ZwQzU1cHdOTlQwS0lxdXRzcFMzVkJio2NpZNkgRzNvT0xvZGFaMW1MVFFGSnZtWm1Db3VsYmExSUlIZWU&client=G3oOLodaZ1mLTQFJvmZmCoulba1IIHee&protocol=oauth2&response_type=token&redirect_uri=https%3A%2F%2Fmyaccount.intostudy.com%2Fcallback&scope=openid%20profile%20email&audience=Into.Student.Gateway.Live&auth0Client=eyJuYW1lIjoiYXV0aDAuanMiLCJ2ZXJzaW9uIjoiOS4xMC40In0%3D";          
                //_driver.Navigate().GoToUrl("https://www.intostudy.com/en");
            }
            else if (_iconfig.GetEnvironment().Equals("Staging"))
            {
                _urls.ISURL = "https://staging.intostudy.com/en";
                _urls.MyAccountURL = "https://login-myaccount-staging.intostudy.com/login?state=g6Fo2SBxb0V4dUV6Qi1JLUNBdzE1SkxSUUd5bThWT0RkTmZDOKN0aWTZIFR4VnVNSmFqMFpvMFZIb3FkZEVCbmhETmxkWWxSZ3NVo2NpZNkgSVpFNFd2dE5jeXM2cXA5T2Q3RkRDZm1XT1dpM2NRZ2w&client=IZE4WvtNcys6qp9Od7FDCfmWOWi3cQgl&protocol=oauth2&response_type=token&redirect_uri=https%3A%2F%2Fmyaccount-staging.intostudy.com%2Fcallback&scope=openid%20profile%20email&audience=Into.Student.Gateway.Staging&auth0Client=eyJuYW1lIjoiYXV0aDAuanMiLCJ2ZXJzaW9uIjoiOS4xMC40In0%3D";
                //_driver.Navigate().GoToUrl("https://staging.intostudy.com/en");

            }
            else
            {
                throw new NoSuitableDriverFound("Driver not found : " + _iconfig.GetBrowser().ToString());
            }
        }

        private ChromeOptions GetChromeOptions()
        {
            ChromeOptions option = new ChromeOptions();
            option.AddArgument("start-maximized");
            option.AddArgument("no-sandbox");
            return option;
        }
        private IWebDriver GetChromeDriver()
        {
            //Driver = new ChromeDriver(ChromeDriverService.CreateDefaultService(), GetChromeOptions(),  TimeSpan.FromMinutes(3));
            _driver = new ChromeDriver(GetChromeOptions());
            _container.RegisterInstanceAs<IWebDriver>(_driver);
            return _driver;
        }
        private IWebDriver GetFirefoxDriver()
        {
            //Driver = new FirefoxDriver(FirefoxDriverService.CreateDefaultService());
            _driver = new FirefoxDriver();
            _driver.Manage().Window.Maximize();
            _container.RegisterInstanceAs<IWebDriver>(_driver);
            return _driver;
        }
    }
}
