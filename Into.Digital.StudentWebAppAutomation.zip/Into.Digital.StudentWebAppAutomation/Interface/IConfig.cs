﻿using System;
using System.Collections.Generic;
using System.Text;
using TestFramework.Configuration;

namespace TestFramework.Interface
{
    public interface IConfig
    {
       
        BrowserType GetBrowser();
        String GetEnvironment();
        int GetPageLoadTimeout();
        int GetImplicitWaitTimeout();
    }
}
