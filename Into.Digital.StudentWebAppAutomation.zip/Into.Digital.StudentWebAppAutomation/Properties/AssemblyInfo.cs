using System.Runtime.InteropServices;
using System;
using System.Reflection;
using NUnit.Framework;

// In SDK-style projects such as this one, several assembly attributes that were historically
// defined in this file are now automatically added during build and populated with
// values defined in project properties. For details of which attributes are included
// and how to customise this process see: https://aka.ms/assembly-info-properties


// Setting ComVisible to false makes the types in this assembly not visible to COM
// components.  If you need to access a type in this assembly from COM, set the ComVisible
// attribute to true on that type.
[assembly: System.Reflection.AssemblyCompanyAttribute("TestFramework")]
[assembly: System.Reflection.AssemblyConfigurationAttribute("Debug")]
[assembly: System.Reflection.AssemblyFileVersionAttribute("1.0.0.0")]
[assembly: System.Reflection.AssemblyInformationalVersionAttribute("1.0.0")]
[assembly: System.Reflection.AssemblyProductAttribute("TestFramework")]
[assembly: System.Reflection.AssemblyTitleAttribute("TestFramework")]
[assembly: System.Reflection.AssemblyVersionAttribute("1.0.0.0")]
[assembly: Parallelizable(ParallelScope.Fixtures)]
//This is 4 by default. Add this line to increase the number of parallel threads
//[assembly: LevelOfParallelism(5)]

[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM.

[assembly: Guid("17c87387-78e6-4423-aca2-56d66f4cd808")]
