﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.Configuration;
using TestFramework.Settings;



namespace TestFramework.ComponentHelper
{
    [Binding]
    public class JSHelper
    {
        public IWebDriver _driver;
        public GenericHelper _genericHelper;
        public JSHelper(IWebDriver driver, GenericHelper genericHelper)
        {
            _driver = driver;
            _genericHelper = genericHelper;
        }
        public void Click(IWebElement element)
        {
            IJavaScriptExecutor executor = ((IJavaScriptExecutor)_driver);
            executor.ExecuteScript("arguments[0].click();", element);
        }
        public void ScrollIntoView(IWebElement element)
        {
            IJavaScriptExecutor executor = ((IJavaScriptExecutor)_driver);
            executor.ExecuteScript("arguments[0].scrollIntoView();", element);
        }
        public void OpenInNewTab(String URL)
        {
            IJavaScriptExecutor executor = ((IJavaScriptExecutor)_driver);
            executor.ExecuteScript("window.open();");
            _genericHelper.SwitchWindow( 1);
            _driver.Url = URL;
        }
        

       
    }
}
