﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using TestFramework.Configuration;
using TestFramework.Hooks;
using TestFramework.Interface;
using TestFramework.Settings;
using AutoIt;


namespace TestFramework.ComponentHelper
{
    [Binding]
    public class GenericHelper
    {
        public IWebDriver _driver;
        public AppSettingReader _iconfig;
        public ScenarioContext _scenarioContext;
        public URLs _urls;
        public GenericHelper(IWebDriver driver, AppSettingReader iconfig, ScenarioContext scenarioContext, URLs urls)
        {
            _driver = driver;
            _iconfig = iconfig;
            _scenarioContext = scenarioContext;
            _urls = urls;
        }
        public void NavigateToIS()
        {
            _driver.Navigate().GoToUrl(_urls.ISURL);
        }
        public void NavigateToMyAccount()
        {
            _driver.Navigate().GoToUrl(_urls.MyAccountURL);
        }

        //takes screenshot of the screen
        public string TakeScreenShot()
        {
            String curDir = Directory.GetCurrentDirectory();
            String reqDir = Path.GetFullPath(Path.Combine(curDir, @"..\..\..\Result\ScreenShots\"));

            //SwitchToLastWindow();
            Screenshot screenshots = ((ITakesScreenshot)_driver).GetScreenshot();
            string cas = _scenarioContext.ScenarioInfo.Title.Replace(" ", "_") +"_" + DateTime.Now.ToString("dd_MM_yy_HH_mm_ss");
            String path = reqDir + cas + ".jpg";
            screenshots.SaveAsFile(path, ScreenshotImageFormat.Png);
            return cas;
        }
        //Makes the code wait for a page to load as per the value in appsettings.json
        public void PageLoadWait() => _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(_iconfig.GetPageLoadTimeout());
        
        //Makes the code wait for an object to be visible as per the value in appsettings.json
        public void ImplicitWait() => _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(_iconfig.GetImplicitWaitTimeout());

        //Makes the code wait for an object to load for a cutom value
        public void ImplicitWait(int timeout)
        {
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(timeout);
        }

        public void UploadDocument(IWebElement element)
        {
            
            element.Click();
            AutoItX.WinActivate("Open");
            Thread.Sleep(1000);
            AutoItX.Send(@"C:\Users\Anam.Wajahat\OneDrive - IUP2 LLP\Desktop\969 MB VIDEO, DELETE.mkv");
            AutoItX.Send("{ENTER}");

        }

        //Makes the code wait till an element is displayed 
        public void WaitForElementInPage(IWebElement locator, int timeout)
        {
            ImplicitWait(1);
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(timeout))
            {
                PollingInterval = TimeSpan.FromMilliseconds(500)
            };
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException), typeof(ElementNotVisibleException));
            wait.Until(Driver => locator.Displayed);
            ImplicitWait();
        }
        public void WaitForElementToContainText(IWebElement locator, int timeout, String text)
        {
            ImplicitWait(1);
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(timeout))
            {
                PollingInterval = TimeSpan.FromMilliseconds(500)
            };
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException), typeof(ElementNotVisibleException));
            wait.Until(Driver => locator.Text.Contains(text));
            ImplicitWait();
        }

        //Makes the code wait till a particular URL loads
        public void WaitForPageLoad(string URL, int timeout)
        {
            ImplicitWait(1);
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(timeout))
            {
                PollingInterval = TimeSpan.FromMilliseconds(250)
            };
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException), typeof(ElementNotVisibleException));
            wait.Until(Driver => (Driver.Url).Contains(URL));
            ImplicitWait();
        }

        public void SwitchWindow(int index = 0)
        {
            IReadOnlyCollection<string> windows = _driver.WindowHandles;
            if (windows.Count < index)
            {
                throw new NoSuchWindowException("Invalid Browser Window index " + index);
            }
            _driver.SwitchTo().Window(_driver.WindowHandles[index]);
        }

        //public void SwitchToLastWindow()
        //{
        //    IReadOnlyCollection<string> windows = _driver.WindowHandles;

        //    _driver.SwitchTo().Window(_driver.WindowHandles[windows.Count]);
        //}

        public void CloseWindow()
        {
            int index = 0;
            _driver.Close();
            IReadOnlyCollection<string> windows = _driver.WindowHandles;
            if (windows.Count < index)
            {
                throw new NoSuchWindowException("Invalid Browser Window index " + index);
            }
            _driver.SwitchTo().Window(_driver.WindowHandles[index]);
        }


    }
}
