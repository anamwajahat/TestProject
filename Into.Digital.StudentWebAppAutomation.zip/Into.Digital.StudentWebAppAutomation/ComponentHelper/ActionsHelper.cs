﻿using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Interfaces;
using OpenQA.Selenium.Appium.MultiTouch;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TestFramework.Configuration;
using TestFramework.Settings;

namespace TestFramework.ComponentHelper
{
    [Binding]
    public class ActionsHelper
    {
        public IWebDriver _driver;
        public ActionsHelper(IWebDriver driver)
        {
            _driver = driver;
        }
        public void MoveToElement(IWebElement element)
        {
            Actions actions = new Actions(_driver);
            actions.MoveToElement(element).Perform();
        }
    }
}
