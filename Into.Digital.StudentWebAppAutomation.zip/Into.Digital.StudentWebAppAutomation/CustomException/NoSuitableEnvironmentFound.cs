﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestFramework.CustomException
{
    class NoSuitableEnvironmentFound : SystemException
    {
        public NoSuitableEnvironmentFound(String msg) : base(msg)
        {

        }
    }
}
