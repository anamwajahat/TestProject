﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestFramework.CustomException
{

    public class NoSuitableDriverFound : SystemException
    {
        public NoSuitableDriverFound(String msg) : base(msg)
        {

        }

    }
}
